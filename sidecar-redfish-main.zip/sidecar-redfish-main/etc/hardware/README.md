# etc/hardware #

下一層目錄，必須對應到`.env`檔的`PROJ_NAME`  
才能正確抓到資訊
