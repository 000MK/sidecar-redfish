from mylib.db.ext_engine import ExtEngine

ext_engine = ExtEngine()
db = ext_engine.get_db()

